# Contest configuration

`qemu-aarch64-baseline.env` is the trusted manifest consumed by
`scripts/contest/run_axvisor_baseline.sh`.  It intentionally contains only
stable identifiers, canonical repository-relative paths, success markers, and
the run timeout.

This directory is not a second source of AxVisor VM definitions.  Board and
guest VM configuration remain owned by `os/axvisor/configs/`.  The
`qemu-aarch64-linux-baseline.toml` file is only a deterministic runner harness:
it preserves the canonical AArch64 QEMU arguments, waits for the minimal Linux
shell prompt, and emits an anchored success marker.  The existing
`os/axvisor/scripts/setup_qemu.sh` creates machine-specific VM configurations
under `os/axvisor/tmp/vmconfigs/`; the baseline wrapper records a copy after a
successful setup.

Because the manifest is sourced by Bash, treat changes to it as executable
code.  Values must remain simple quoted strings, paths must be relative to the
repository or AxVisor directory as documented in the file, and no commands or
shell substitutions may be added.
