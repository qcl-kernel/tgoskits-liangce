# AxVisor 固定 HPA 与宿主预留内存设计

状态：Phase A/B 源码与编译门禁完成；Phase C 实机 allocator/DMA/IP 仍阻塞  
基线：`rcore-os/tgoskits` `dev`，`01e053105e243d1fdd1c03f6f850b266efbe8de0`  
风险级别：高风险（宿主 allocator、固定物理内存、stage-2 页表与 passthrough DMA）

## 1. 结论

Zephyr 不能在当前 `MapAlloc` 内存上直接启用 passthrough virtio-net。Guest GPA
`0x4000_0000` 会映射到运行时分配的任意 HPA，而外层设备 DMA 地址仍按 Guest
看到的物理地址发出；没有 IOMMU 或 bounce backend 时，两者不一致会访问错误的
宿主物理内存。

本阶段选择“宿主启动前静态预留 + `MapReserved` 固定映射”，但必须分成两个
独立条件：

1. 宿主 FDT 在 allocator 初始化前把专用 HPA carveout 从普通 RAM 中排除；
2. AxVM 只把已证明属于该专用 carveout 的 HPA 映射给指定 VM。

跨 VM `PhysicalResourceLease` 只能防止两个 VM 同时声明同一 HPA，不能证明该 HPA
没有被 AxVisor 内核、per-CPU 数据或全局 allocator 使用。只改 VM TOML、Guest DTB
或 resource claim 都不能关闭 allocator ownership gate。

## 2. 当前实现审计

### 2.1 `MapReserved` 不是“预留”操作

历史实现中的 `virtualization/axvm/src/vm/mod.rs::map_reserved_memory_region()` 直接建立
GPA=HPA 的 stage-2 映射，并把 `needs_dealloc` 设为 `false`，既不调用宿主 allocator
预留页，也不验证 HPA 区间的宿主归属。当前 Phase A/B 已把这两项拆成显式合同：
someboot 在 allocator 初始化前解析专用 carveout，AxVM 在映射前只接受
`VM ID + HPA start + size` 完全相等的不可变 manifest 条目。

更具体地说，历史实现把 `hva` 也写成 `gpa`。当宿主启用重定位或 direct-map 不是
identity 时，`VMMemoryRegion::hpa()` 会再次执行 `virt_to_phys(hva)`，从而得到错误
HPA。这个地址转换缺陷可以独立修复为：

```text
hpa = HostPhysAddr(gpa)
hva = host.phys_to_virt(hpa)
stage-2: gpa -> hpa
```

当前实现已采用上述转换，并把授权放在 `phys_to_virt`、stage-2 修改和 region 登记
之前。它仍不证明某次真实启动确实使用了目标 DTB，也不证明 allocator 运行时 FREE
列表已经排除该范围。

### 2.2 allocator 已在 VM 创建前接管 FREE RAM

启动链由 `someboot` 解析宿主 FDT，`axplat-dyn` 再把 `MemoryType::Free` 暴露为
`phys_ram_ranges()`，把 `Reserved/KImage/PerCpuData` 聚合为
`reserved_phys_ram_ranges()`。`axhal` 从 RAM 中扣除这些 reserved ranges 后初始化
allocator。VM 配置被解析时，这个过程已经完成，因而 VM 创建路径不能再靠
“声明 MapReserved”把一段 FREE RAM 安全取回。

Devicetree Specification 的 `/reserved-memory` 规则要求操作系统排除所描述的
物理区间，并允许静态子节点用 `reg` 指定地址和大小：

- https://devicetree-specification.readthedocs.io/en/latest/chapter3-devicenodes.html#reserved-memory-node

当前 `someboot/src/fdt/memory.rs` 同时解析 FDT reservation block 和
`/reserved-memory` 子节点，并在 allocator 初始化前记录为 `MemoryType::Reserved`。
这正是固定 carveout 应进入的时序边界。

### 2.3 不能直接恢复 `alloc_pages_at`

本仓库提交 `8f0e568a2` 移除了 AxVisor/ArceOS 对 `ax-allocator` bitmap page
allocator 的依赖，切换到 TLSF/buddy-slab 后，`alloc_pages_at` 只剩
`unimplemented!()`。直接恢复固定地址分配需要重新设计 allocator 元数据、并发、
碎片与回收语义，且仍不能可靠区分 VM carveout 与宿主关键区，不是本阶段的最小
安全方案。

### 2.4 “任意 RESERVED”仍然不够

`axplat-dyn::reserved_phys_ram_ranges()` 当前还包含 `KImage` 和 `PerCpuData`。因此
简单检查目标范围是否落入 `RESERVED` 会错误地允许 VM 映射 AxVisor 内核或
per-CPU 数据。安全检查必须识别“专门授予 VM 的 carveout”，不能只检查通用
`MemRegionFlags::RESERVED`。

## 3. 目标与非目标

### 3.1 成功标准

- 固定 HPA 在宿主 allocator 初始化前从 FREE RAM 中排除；
- carveout 有稳定、可审计的 VM 归属标识，且与配置的 `MapReserved` 起点和大小完全相等；
- VM 创建时拒绝 FREE、MMIO、KImage、PerCpuData、普通 reserved 或跨边界范围；
- AxVM 记账中的 HVA 由宿主 `phys_to_virt(HPA)` 得到；
- 两个 VM 的固定 HPA、passthrough MMIO、物理 IRQ 与 pCPU claim 不重叠；
- 当前 QEMU head 上保存宿主 memory map、allocator 排除证据和 stage-2 查询证据；
- 只有 DMA smoke 和 Guest 间 IP 证据通过后，才关闭 `blocked_dma_console` 中的
  DMA 子门槛。

### 3.2 非目标

- 本设计不实现 IOMMU/SMMU、DMA remapping 或 bounce buffer；
- 不证明设备 stream ID、缓存一致性、reset/quiesce 或中断隔离；
- 不恢复通用 `alloc_pages_at`；
- 不把控制台、HyperCall、共享内存、原始 MMIO 或 `vsock` 作为 Guest 间通信；
- 不在地址尚未由 QEMU/FDT 实证前硬编码 `0x1_0000_0000` 为最终 carveout；
- 不把固定 HPA 所有权证明升级为双 Guest 启动或 IP 通信证明。

## 4. 方案比较

| 方案 | allocator 安全 | DMA 地址一致性 | 复杂度 | 结论 |
|---|---|---|---|---|
| 保持 Zephyr `MapAlloc` 并启用 passthrough | 否 | 否 | 低 | 拒绝 |
| VM 启动时调用 `alloc_pages_at` | 取决于重做 allocator | 可以 | 高 | 当前后端不支持，拒绝 |
| 宿主 FDT 静态预留 + 泛化 `RESERVED` 检查 | 部分 | 可以 | 中 | 会误接纳 KImage/PerCpu，拒绝 |
| 宿主 FDT 专用 VM carveout + 精确归属检查 | 是 | 可以 | 中 | 采用 |
| emulated/bounce virtio-net | 是 | 可转换 | 高 | 长期替代方案 |
| IOMMU/SMMU | 是 | 可重映射 | 很高 | 真机长期方案 |

## 5. 选定的所有权合同

### 5.1 宿主 FDT

QEMU runner 应先获得与最终 machine 参数完全一致的宿主 DTB，再生成一个只新增
专用 carveout 的派生 DTB。静态节点必须：

- 位于 `/reserved-memory`；
- 使用固定 `reg = <HPA SIZE>`，不用动态 `size` 分配；
- 具备项目专用 compatible，例如 `axvisor,vm-carveout-v1`；
- 具备唯一 VM ID 属性，例如 `axvisor,vm-id = <2>`；
- 不带 `reusable`；是否使用 `no-map` 必须由宿主 direct-map 访问需求决定，不能
  在未验证 `phys_to_virt` 行为时直接启用；
- 地址、大小至少 2 MiB 对齐，并完整位于 QEMU 报告的 RAM；
- 与宿主 kernel、FDT、initrd、per-CPU、其他 carveout 和设备 MMIO 不重叠。

QEMU `virt` 的 `highmem` 与 `compact-highmem` 会影响 32 位以上区域布局，因此候选
`0x1_0000_0000` 只能通过当前固定 QEMU 版本和实际 `dumpdtb` 验证，不能按经验
直接使用：

- https://qemu.readthedocs.io/en/v8.2.10/system/arm/virt.html

### 5.2 AxVM 运行时

建议增加只读的宿主能力边界，而不是让 `axvm` 任意访问平台内部 memory map：

```text
HostVmCarveouts::find_vm_carveout(vm_id, hpa, size)
    -> exact owned carveout | typed rejection
```

该能力应从保存的宿主 FDT 解析项目专用属性，或由启动层在 allocator 初始化后生成
不可变 manifest。它必须区分：专用 VM carveout、普通 reserved、KImage、
PerCpuData、MMIO 与 FREE RAM。

`MapReserved` 准备顺序为：

1. 校验非零、2 MiB 对齐、地址加法不溢出；
2. 用 VM ID、HPA 起点和大小查找一个三元组完全相等的专用 carveout；
3. 确认 `PhysicalResourceLease` 仍持有同一 HPA claim；
4. 计算 `hpa = gpa` 与 `hva = host.phys_to_virt(hpa)`；
5. 建立 stage-2 `gpa -> hpa`；
6. 记录不可释放的 `VMMemoryRegion`；
7. VM 销毁时只 unmap，不把 carveout 交回全局 allocator。

任一步失败都不得留下 stage-2 映射或 `memory_regions` 条目。

## 6. Zephyr 迁移

当前 `zephyr-smp1-dual.toml` 保持 `MapAlloc` 和 `blocked_dma_console`，不能仅把
map type 改为 `MapReserved`。迁移前必须：

1. 从当前 QEMU `dumpdtb` 和启动 memory map 选择实际空闲且可预留的 128 MiB HPA；
2. 生成并校验宿主派生 DTB；
3. 用 overlay 重链接 Zephyr `zephyr,sram`、链接地址和镜像 load/entry；
4. 把 VM 的 GPA/HPA 合同同步为该 carveout；
5. 保存 `zephyr.dts`、`.config`、ELF/BIN 与哈希；
6. 先运行无 passthrough 的单 Guest memory smoke；
7. 再运行 virtio-net DMA smoke，最后才进入双 Guest IP 测试。

## 7. 分阶段实现与验证

### Phase A：独立地址转换修复

- [x] 为 `MapReserved` 增加会在 identity-HVA 旧实现上失败的静态/单元契约；
- [x] `hva` 改为 `host.phys_to_virt(hpa)`；
- 不改变任何双 Guest 配置，不声称 allocator ownership 已完成。

### Phase B：专用 carveout 解析与 fail-closed 校验

- [x] 先为错误 VM ID、部分覆盖、普通 reserved、FREE、KImage、PerCpu、MMIO、重叠和
  溢出写失败测试；
- [x] 增加 someboot 专用 parser/预留注入和最小只读 host capability；普通 merged
  reserved ranges 不进入授权 manifest；
- [x] 缺少专用标识、VM ID/HPA/size 任一不精确匹配时 `MapReserved` 必须失败；拒绝
  发生在 `phys_to_virt`、stage-2 修改和 `memory_regions.push` 之前。

### Phase C：QEMU/Zephyr 实证

- 固定 QEMU 版本、完整参数与派生 DTB；
- 启动日志证明 carveout 不在 allocator FREE 区；
- stage-2 查询证明 Zephyr GPA 映射到预期 HPA；
- DMA 前后对目标缓冲做 nonce/hash 校验；
- 保存失败注入：移除 reservation、改 VM ID、缩短范围时 VM 必须拒绝准备；
- 最后单独验证 Linux 与 Zephyr 的 TCP/UDP/IP 通信。

## 8. 回滚

- Phase A 地址转换修复可独立回滚，但回滚后不得使用 relocated host 的
  `MapReserved`；
- Phase B 失败时移除 contest carveout 配置并继续 `MapAlloc` headless smoke；
- Phase C 失败时保留证据，恢复 `blocked_dma_console`，不得用根节点透传、共享 UART
  或非 IP 通道绕过；
- 宿主 FDT 派生文件必须按 run 生成，不覆盖仓库中的原始 QEMU DTB。

## 9. 当前完成边界

Phase A/B 已完成源码、host 单测、严格 Clippy 和 AArch64 target check：专用
`axvisor,vm-carveout-v1` parser 会在 allocator 初始化前注入 Reserved，独立只读
manifest 经 axplat/axhal 暴露，AxVM 只授权 VM ID/HPA/size 完全相等的 `MapReserved`。
静态 DTS/TOML validator 也已落地，但它不证明 QEMU 实际使用该 DTB。

尚未完成的是 Phase C：最终 8 GiB QEMU 参数对应的宿主 DTB 派生与哈希、启动时
allocator FREE 排除日志、stage-2 查询、Zephyr 重链接、DMA nonce/hash 以及双 Guest
TCP/UDP/IP。故 fixed-HPA/DMA 运行 gate 继续保持阻塞，不能仅凭 Phase A/B 解开
`blocked_dma_console`。
