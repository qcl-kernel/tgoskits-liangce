# AxVisor baseline evidence

This directory indexes the unmodified QEMU AArch64 AxVisor guest baseline.
The source revision, environment, exact commands, resolved configuration, raw
console output, result status, and checksums are grouped by a stable run ID.

## Layout

```text
results/baseline/
├── README.md
├── index.csv
└── runs/<run-id>/
    ├── host-environment.json       # optional Windows-host capture
    ├── runtime-environment.txt
    ├── git-status.txt
    ├── source-state/
    │   ├── worktree.patch
    │   ├── untracked-files.tar
    │   └── untracked-files.sha256
    ├── configs/
    ├── arceos/
    ├── linux/
    └── checksums.sha256
```

`run-id` must contain only letters, digits, dots, underscores, and hyphens.
Using the same ID for the PowerShell host capture and Bash guest run joins both
parts of the evidence bundle.

## Tracking policy

`README.md` and `index.csv` are small reviewable records.  `runs/` contains
machine-specific raw logs and generated paths and is intended to remain local;
review and sanitize evidence before publishing it.  Do not add guest images,
root filesystems, Cargo build output, QEMU raw logs, core dumps, credentials, or
host serial numbers to Git.

The scoped `/results/baseline/runs/` ignore rule keeps raw bundles out of Git.
`index.csv` is a local audit ledger while those bundles remain unpublished, so
its `summary_path` entries are intentionally not resolvable in a fresh clone.
Before sharing a result, copy a reviewed, desensitized status summary into a
tracked publication directory and update the corresponding documentation.

## Status meanings

- `passed`: QEMU exited successfully and the guest-specific marker was seen.
- `setup_failed`: the existing AxVisor guest setup script failed.
- `timed_out`: the bounded QEMU command reached its configured timeout.
- `marker_missing`: QEMU exited but the required guest marker was absent.
- `qemu_failed`: the QEMU build/run command returned a non-zero status.
